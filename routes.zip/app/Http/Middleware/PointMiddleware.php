<?php

namespace App\Http\Middleware;

use App\Action;
use Closure;

class PointMiddleware {
    /**
     * Handle an incoming request.
     *
     * @param \Illuminate\Http\Request $request
     * @param \Closure $next
     * @return mixed
     */
    public function handle($request, Closure $next) {
        $data = Action::where([['users_id','=',auth()->id()],['status','=',1]])->get();
        $p = 0;
        $per = 0;
        if (count($data) > 0) {
            foreach ($data as $d) {
                $p+=$d->points;
            }
            $per = $p*100/5000;
        }
        session(['point'=>$p,'percent'=>ceil($per)."%"]);
        return $next($request);
    }
}
